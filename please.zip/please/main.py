# Standard library imports
import os
import json
import time
import random
import datetime
from functools import wraps

# Third-party imports
import numpy as np
import pandas as pd
import requests
import yfinance as yf
import faiss
from dotenv import load_dotenv
from flask import Flask, render_template, request, jsonify
from flask_caching import Cache
from sentence_transformers import SentenceTransformer
import google.generativeai as genai

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Configure Flask-Caching
cache_config = {
    'CACHE_TYPE': os.getenv('CACHE_TYPE', 'simple'),
    'CACHE_DEFAULT_TIMEOUT': int(os.getenv('CACHE_DEFAULT_TIMEOUT', 300)),
    'CACHE_THRESHOLD': int(os.getenv('CACHE_THRESHOLD', 1000)),  # Maximum number of items in cache
    'CACHE_KEY_PREFIX': 'market_analysis_',  # Prefix for cache keys
}

try:
    app.config.update(cache_config)
    cache = Cache(app)
except Exception as e:
    print(f"[ERROR] Failed to initialize cache: {str(e)}")
    # Fallback to a simple cache with default settings
    app.config['CACHE_TYPE'] = 'simple'
    app.config['CACHE_DEFAULT_TIMEOUT'] = 300
    cache = Cache(app)
    print("[WARN] Using fallback cache configuration")

# API Keys and Configuration
NEWS_API_KEY = os.getenv('NEWS_API_KEY', '8df6cf4cbc4c42cdb7fe0d2ee438ccd5')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'AIzaSyBRzLEPudJzVNDQpckpxhbkA3aF9Inr5v0')

# Global configuration
CONFIG = {
    'cache_timeout': int(os.getenv('CACHE_DEFAULT_TIMEOUT', 300)),
    'max_retries': int(os.getenv('MAX_RETRIES', 3)),
    'request_timeout': int(os.getenv('REQUEST_TIMEOUT', 10)),
    'batch_size': int(os.getenv('BATCH_SIZE', 10)),
    'min_cache_time': 60,  # Minimum cache time in seconds
    'max_cache_time': 3600  # Maximum cache time in seconds
}

# Validate configuration
for key, value in CONFIG.items():
    if isinstance(value, int) and value <= 0:
        print(f"[WARN] Invalid configuration value for {key}: {value}. Using default.")
        CONFIG[key] = 300 if 'timeout' in key else 3  # Set sensible defaults

# Sector definitions
SECTORS = {
    'Technology': ['AAPL', 'MSFT', 'GOOGL', 'META', 'NVDA', 'INTC', 'AMD', 'CRM', 'ADBE', 'CSCO'],
    'Healthcare': ['JNJ', 'UNH', 'PFE', 'ABT', 'TMO', 'MRK', 'DHR', 'BMY', 'ABBV', 'LLY'],
    'Finance': ['JPM', 'BAC', 'WFC', 'C', 'GS', 'MS', 'BLK', 'AXP', 'V', 'MA'],
    'Consumer': ['AMZN', 'WMT', 'HD', 'NKE', 'MCD', 'SBUX', 'TGT', 'COST', 'PG', 'KO'],
    'Energy': ['XOM', 'CVX', 'COP', 'SLB', 'EOG', 'PXD', 'MPC', 'PSX', 'VLO', 'OXY'],
    'Industrial': ['BA', 'CAT', 'GE', 'HON', 'UNP', 'RTX', 'LMT', 'MMM', 'DE', 'EMR']
}

# ============================================================
# 1. SETUP: Load Historical Data and Build FAISS Index
# ============================================================

# File paths configuration
WORKSPACE_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_PATHS = {
    'news_file': os.path.join(WORKSPACE_ROOT, 'historical_financial_news_with_reactions.json'),
    'embeddings_file': os.path.join(WORKSPACE_ROOT, 'historical_news_embeddings.npy'),
    'faiss_index': os.path.join(WORKSPACE_ROOT, 'financial_news_index.faiss')
}

# Initialize global variables
index_loaded = False
historical_news = []
faiss_index = None
embed_model = None

# Initialize FAISS on startup
def initialize_faiss():
    """Initialize FAISS index and load historical data"""
    global index_loaded, historical_news, faiss_index, embed_model
    
    try:
        print("[INFO] Starting FAISS initialization...")
        
        # Check if required files exist
        for key, filepath in DATA_PATHS.items():
            if not os.path.exists(filepath):
                print(f"[ERROR] Required file not found: {filepath}")
                return False
            print(f"[INFO] Found {key} at {filepath}")

        # Load historical news data
        try:
            print(f"[INFO] Loading historical news from {DATA_PATHS['news_file']}")
            with open(DATA_PATHS['news_file'], 'r', encoding='utf-8') as f:
                historical_news = json.load(f)
            print(f"[INFO] Loaded {len(historical_news)} historical news articles")
        except json.JSONDecodeError as e:
            print(f"[ERROR] Failed to parse historical news file: {str(e)}")
            return False
        except Exception as e:
            print(f"[ERROR] Failed to load historical news: {str(e)}")
            return False

        # Initialize the SentenceTransformer
        try:
            print("[INFO] Initializing SentenceTransformer...")
            embed_model = SentenceTransformer("all-MiniLM-L6-v2")
            print("[INFO] Successfully initialized SentenceTransformer")
        except Exception as e:
            print(f"[ERROR] Failed to initialize SentenceTransformer: {str(e)}")
            return False

        # Load FAISS index
        try:
            print(f"[INFO] Loading FAISS index from {DATA_PATHS['faiss_index']}")
            faiss_index = faiss.read_index(DATA_PATHS['faiss_index'])
            print(f"[INFO] Successfully loaded FAISS index with {faiss_index.ntotal} vectors")
            
            # Verify index is working
            test_query = np.random.rand(embed_model.get_sentence_embedding_dimension()).astype('float32').reshape(1, -1)
            _, test_indices = faiss_index.search(test_query, 1)
            print("[INFO] FAISS index test search successful")
            
            index_loaded = True
            return True
        except Exception as e:
            print(f"[ERROR] Failed to load FAISS index: {str(e)}")
            faiss_index = None
            index_loaded = False
            return False

    except Exception as e:
        print(f"[ERROR] Failed to initialize FAISS: {str(e)}")
        index_loaded = False
        historical_news = []
        faiss_index = None
        embed_model = None
        return False

# ============================================================
# 2. UTILITY FUNCTIONS
# ============================================================

# Utility decorators
def retry_on_exception(retries=3, backoff_factor=0.3):
    """Retry decorator with exponential backoff"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for i in range(retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if i == retries - 1:  # Last attempt
                        raise
                    wait_time = backoff_factor * (2 ** i)  # Exponential backoff
                    time.sleep(wait_time)
            return None
        return wrapper
    return decorator

def handle_api_error(func):
    """Decorator to handle API errors consistently"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except requests.exceptions.RequestException as e:
            print(f"API request failed: {str(e)}")
            return jsonify({
                'status': 'error',
                'error': 'API request failed',
                'details': str(e)
            }), 503
        except Exception as e:
            print(f"Unexpected error: {str(e)}")
            return jsonify({
                'status': 'error',
                'error': 'Internal server error',
                'details': str(e)
            }), 500
    return wrapper

@retry_on_exception(retries=CONFIG['max_retries'])
def get_last_n_days_market_data(ticker, n_days=10):
    """Fetches market data for the last n_days for the given ticker using yfinance."""
    today = datetime.datetime.now()
    start_date = (today - datetime.timedelta(days=n_days)).strftime("%Y-%m-%d")
    end_date = (today + datetime.timedelta(days=1)).strftime("%Y-%m-%d")

    try:
        data = yf.download(ticker, start=start_date, end=end_date)
        
        if data.empty:
            return f"No market data available for the last {n_days} days.", None

        market_data_output = f"Market data for the last {n_days} days for {ticker}:\n"
        for date, row in data.iterrows():
            market_data_output += f"{date.strftime('%Y-%m-%d')}: Close = ${row['Close']:.2f}, Volume = {row['Volume']:,}\n"

        return market_data_output, data
    except Exception as e:
        print(f"Error fetching market data for {ticker}: {str(e)}")
        raise


def get_yesterdays_market_data(ticker):
    """
    Fetch market data for 'yesterday' (based on current date - 1 day)
    using yfinance. Adjust the date range as needed.
    """
    try:
        yesterday = datetime.datetime.now() - datetime.timedelta(days=1)
        start_date = yesterday.strftime("%Y-%m-%d")
        # Since yfinance uses exclusive end date, we add 1 day:
        end_date = (yesterday + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
        data = yf.download(ticker, start=start_date, end=end_date)

        # Extract key info. If no data is found, return defaults
        if not data.empty:
            try:
                # Use .iloc[0] to get scalar values instead of Series
                close = float(data['Close'].iloc[-1].item())
                previous_close = float(data['Close'].iloc[0].item())
                ticker_info = yf.Ticker(ticker).info
                market_cap = int(ticker_info.get("marketCap", 0))
                
                # Format values
                close_str = f"{close:.2f}"
                prev_close_str = f"{previous_close:.2f}"
                market_cap_str = str(market_cap)
            except (ValueError, TypeError, AttributeError) as e:
                print(f"Error converting market data values: {str(e)}")
                close_str = prev_close_str = market_cap_str = "N/A"
        else:
            close_str = prev_close_str = market_cap_str = "N/A"

        market_data_text = (
            f"Current market data for {ticker} (as of yesterday):\n"
            f"- Closing Price: ${close_str}\n"
            f"- Previous Close: ${prev_close_str}\n"
            f"- Market Cap: {market_cap_str}\n"
        )
        return market_data_text, close_str, prev_close_str, market_cap_str
    except Exception as e:
        print(f"Error fetching market data for {ticker}: {str(e)}")
        return "Error fetching market data", "N/A", "N/A", "N/A"


def get_historical_chart_data(ticker, period="6mo"):
    """
    Fetches historical stock data for charts
    """
    try:
        print(f"[INFO] Fetching historical data for {ticker} over {period}")
        data = yf.download(ticker, period=period, progress=False)
        
        if data.empty:
            print(f"[WARN] No historical data found for {ticker}")
            return None

        # Verify data structure
        print(f"[DEBUG] DataFrame shape: {data.shape}")
        print(f"[DEBUG] DataFrame columns: {data.columns.tolist()}")
        
        # Convert DataFrame to lists properly
        try:
            dates = data.index.strftime('%Y-%m-%d').tolist()
            # Ensure we're getting closing prices and volumes as floats
            prices = [float(price) for price in data['Close'].values]
            volumes = [float(vol) for vol in data['Volume'].values]
            
            print(f"[INFO] Successfully processed {len(dates)} data points")
            print(f"[DEBUG] Sample data:")
            print(f"First date: {dates[0]}, Price: {prices[0]}, Volume: {volumes[0]}")
            print(f"Last date: {dates[-1]}, Price: {prices[-1]}, Volume: {volumes[-1]}")
            
            chart_data = {
                'dates': dates,
                'prices': prices,
                'volumes': volumes
            }
            
            # Verify the output structure
            print(f"[DEBUG] Chart data structure:")
            print(f"Dates length: {len(chart_data['dates'])}")
            print(f"Prices length: {len(chart_data['prices'])}")
            print(f"Volumes length: {len(chart_data['volumes'])}")
            
            return chart_data
            
        except Exception as e:
            print(f"[ERROR] Error converting data types: {str(e)}")
            import traceback
            traceback.print_exc()
            return None
            
    except Exception as e:
        print(f"[ERROR] Error fetching chart data for {ticker}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


def generate_rag_prompt_with_market(new_article, similar_articles, market_data_text):
    """
    Build a RAG prompt including the new article details,
    detailed market data (last 10 days), and similar historical articles.
    """
    prompt = f"""New Financial News Article:
Title: {new_article['title']}
Content: {new_article['content']}

Ticker: {new_article.get('ticker', 'N/A')}
{market_data_text}

Historical Context:"""
    for idx, art in enumerate(similar_articles, 1):
        prompt += f"""\n\n{idx}. Title: {art['title']}
   Reaction: Price Change = {art['reaction']['price_change']}%, Volume Spike = {art['reaction']['volume_spike']}"""

    prompt += """

Based on the above information, analyze and explain:
- How the market might react to this new article.
- Whether the recommendation is to BUY, HOLD, or SELL.
- Provide a brief justification referencing historical patterns and current market conditions.
"""
    return prompt


def find_similar_articles(article, top_k=5):
    """
    Find similar historical articles using FAISS
    """
    try:
        if not index_loaded or not embed_model or not faiss_index:
            print("[ERROR] FAISS index not properly initialized")
            print(f"index_loaded: {index_loaded}, embed_model: {embed_model is not None}, faiss_index: {faiss_index is not None}")
            return []

        # Create embedding for the new article
        print(f"\n[INFO] Finding similar articles for: {article['title']}")
        article_text = f"{article['title']}. {article['content']}"
        article_embedding = embed_model.encode([article_text])[0]
        
        # Convert to correct format for FAISS
        article_embedding = np.array([article_embedding]).astype('float32')
        
        # Search for similar articles
        print("[INFO] Searching FAISS index...")
        distances, indices = faiss_index.search(article_embedding, min(top_k * 2, faiss_index.ntotal))  # Get more candidates
        
        similar_articles = []
        print("\n[INFO] Processing search results:")
        for i, idx in enumerate(indices[0]):
            if idx >= len(historical_news):
                print(f"[WARN] Index {idx} out of range for historical_news length {len(historical_news)}")
                continue
                
            hist_article = historical_news[idx]
            
            # Calculate similarity score (convert distance to similarity)
            similarity = 1 / (1 + distances[0][i])
            similarity_score = round(similarity * 100, 2)
            
            # Only include articles with reasonable similarity
            if similarity_score < 30:  # Minimum similarity threshold
                continue
            
            article_data = {
                'title': hist_article.get('title', 'No Title'),
                'content': hist_article.get('content', 'No Content'),
                'date': hist_article.get('date', 'Unknown Date'),
                'source': hist_article.get('source', 'Unknown Source'),
                'ticker': hist_article.get('ticker', 'Unknown Ticker'),
                'reaction': hist_article.get('reaction', {
                    'price_change': 0.0,
                    'volume_spike': 0.0
                }),
                'similarity_score': similarity_score
            }
            similar_articles.append(article_data)
            
            print(f"- Match {len(similar_articles)}: {similarity_score}% - {article_data['title']}")
            
        # Sort by similarity score and take top_k
        similar_articles.sort(key=lambda x: x['similarity_score'], reverse=True)
        similar_articles = similar_articles[:top_k]
        
        print(f"\n[INFO] Found {len(similar_articles)} relevant matches above similarity threshold")
        return similar_articles
    except Exception as e:
        print(f"[ERROR] Error finding similar articles: {str(e)}")
        import traceback
        traceback.print_exc()
        return []


def analyze_market_reactions(similar_articles):
    """
    Analyze market reactions from similar historical events
    """
    if not similar_articles:
        return "No similar historical events found for analysis."
    
    try:
        # Calculate average price and volume impacts
        price_changes = [art['reaction']['price_change'] for art in similar_articles]
        volume_spikes = [art['reaction']['volume_spike'] for art in similar_articles]
        
        avg_price_change = sum(price_changes) / len(price_changes)
        avg_volume_spike = sum(volume_spikes) / len(volume_spikes)
        
        # Count positive and negative reactions
        positive_reactions = sum(1 for pc in price_changes if pc > 0)
        negative_reactions = sum(1 for pc in price_changes if pc < 0)
        
        # Generate analysis text
        analysis = f"""Based on {len(similar_articles)} similar historical events:

1. Price Impact:
   - Average price change: {avg_price_change:+.2f}%
   - {positive_reactions} positive vs {negative_reactions} negative reactions
   
2. Volume Impact:
   - Average volume spike: {avg_volume_spike:+.2f}%
   
3. Most Similar Events:"""

        # Add details of each similar event
        for i, article in enumerate(similar_articles, 1):
            analysis += f"""

Event {i}:
- Title: {article['title']}
- Date: {article['date']}
- Price Change: {article['reaction']['price_change']:+.2f}%
- Volume Change: {article['reaction']['volume_spike']:+.2f}%
- Similarity Score: {article['similarity_score']}%"""
            
        return analysis
    except Exception as e:
        print(f"[ERROR] Error analyzing market reactions: {str(e)}")
        return "Error analyzing historical market reactions."


def analyze_article_with_agent(article):
    """
    Analyze article using similar historical events and generate recommendation
    """
    try:
        # Find similar historical articles
        similar_articles = find_similar_articles(article)
        
        # Generate market reaction analysis
        market_analysis = analyze_market_reactions(similar_articles)
        
        # Combine with current article for final analysis
        analysis_prompt = f"""Analyzing news article:
Title: {article['title']}
Content: {article['content']}

Historical Analysis:
{market_analysis}

Based on this information, please provide:
1. A comprehensive market analysis
2. A clear BUY/HOLD/SELL recommendation
3. Key factors supporting this recommendation
"""
        
        try:
            # Configure Gemini
            genai.configure(api_key=GEMINI_API_KEY)
            
            # Create the model
            model = genai.GenerativeModel('gemini-2.0-flash')
                        # Generate the response
            response = model.generate_content(
                analysis_prompt,
                generation_config={
                    'temperature': 0.7,
                    'top_p': 0.8,
                    'top_k': 40,
                    'max_output_tokens': 2048,
                }
            )
            
            # Check if response is valid
            if response and hasattr(response, 'text'):
                recommendation_text = response.text
            else:
                print("[WARN] Invalid response from Gemini API")
                recommendation_text = "Unable to generate recommendation at this time."
                
        except Exception as e:
            print(f"[ERROR] Gemini API error: {str(e)}")
            # Fallback to a basic analysis without AI
            recommendation_text = f"""Based on historical analysis:
            
1. Market Analysis:
- Found {len(similar_articles)} similar historical events
- Average price impact: {sum(art['reaction']['price_change'] for art in similar_articles) / len(similar_articles):.2f}% if similar articles exist
- Average volume impact: {sum(art['reaction']['volume_spike'] for art in similar_articles) / len(similar_articles):.2f}% if similar articles exist

2. Recommendation: HOLD (default fallback)

3. Key Factors:
- Limited to historical data analysis
- AI-powered analysis currently unavailable
- Please check back later for full analysis"""
        
        return recommendation_text, analysis_prompt, similar_articles
        
    except Exception as e:
        print(f"[ERROR] Error in article analysis: {str(e)}")
        import traceback
        traceback.print_exc()
        return "Unable to analyze article at this time.", "", []


def get_market_data(ticker):
    """
    Fetch market data including weekly changes
    """
    try:
        # Get data for the last 7 days
        end_date = datetime.datetime.now()
        start_date = end_date - datetime.timedelta(days=7)
        data = yf.download(ticker, start=start_date, end=end_date)

        if not data.empty:
            try:
                # Get latest and week-ago prices
                latest_close = float(data['Close'].iloc[-1].item())
                week_ago_close = float(data['Close'].iloc[0].item())
                
                # Get ticker info
                ticker_info = yf.Ticker(ticker).info
                market_cap = int(ticker_info.get("marketCap", 0))
                
                # Calculate weekly change
                weekly_change = ((latest_close - week_ago_close) / week_ago_close) * 100
                
                # Format values
                close_str = f"{latest_close:.2f}"
                week_ago_str = f"{week_ago_close:.2f}"
                weekly_change_str = f"{weekly_change:+.2f}%"
                market_cap_str = str(market_cap)

                market_data_text = (
                    f"Market data for {ticker}:\n"
                    f"- Current Price: ${close_str}\n"
                    f"- Week Ago Price: ${week_ago_str}\n"
                    f"- Weekly Change: {weekly_change_str}\n"
                    f"- Market Cap: {market_cap_str}\n"
                )
                
                return market_data_text, close_str, week_ago_str, market_cap_str, weekly_change_str
            except (ValueError, TypeError, AttributeError) as e:
                print(f"Error converting market data values: {str(e)}")
                return "Error processing market data", "N/A", "N/A", "N/A", "N/A"
        else:
            return "No market data available", "N/A", "N/A", "N/A", "N/A"
    except Exception as e:
        print(f"Error fetching market data for {ticker}: {str(e)}")
        return "Error fetching market data", "N/A", "N/A", "N/A", "N/A"


@retry_on_exception(retries=CONFIG['max_retries'])
def fetch_latest_news(ticker="TSLA"):
    """
    Fetch the most recent news article for the given ticker using NewsAPI.
    """
    url = (
        f"https://newsapi.org/v2/everything?"
        f"q={ticker}&"
        f"apiKey={NEWS_API_KEY}&"
        f"sortBy=publishedAt&"
        f"language=en"
    )

    try:
        response = requests.get(url, timeout=CONFIG['request_timeout'])
        response.raise_for_status()  # Raise an error for bad status codes
        data = response.json()

        if data.get("status") == "ok" and data.get("totalResults", 0) > 0:
            article = data["articles"][0]  # Take the most recent article
            
            # Validate required fields
            if not article.get("title") or not (article.get("content") or article.get("description")):
                print(f"[WARN] Invalid article data for {ticker}")
                return None

            return {
                "title": article["title"],
                "content": article.get("content") or article.get("description", ""),
                "ticker": ticker,
                "url": article.get("url", ""),
                "source": article.get("source", {}).get("name", "Unknown"),
                "publishedAt": article.get("publishedAt", "")
            }
        else:
            error_msg = data.get("message", "Unknown error")
            print(f"[WARN] NewsAPI error for {ticker}: {error_msg}")
            return None
            
    except requests.exceptions.Timeout:
        print(f"[ERROR] Request timeout while fetching news for {ticker}")
        raise
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Request failed while fetching news for {ticker}: {str(e)}")
        raise
    except Exception as e:
        print(f"[ERROR] Unexpected error while fetching news for {ticker}: {str(e)}")
        raise


def parse_recommendation(recommendation_text):
    """
    Simple parser to extract the recommendation (BUY/HOLD/SELL) from Gemini output.
    """
    text_upper = recommendation_text.upper()
    if "BUY" in text_upper:
        return "BUY"
    elif "SELL" in text_upper:
        return "SELL"
    else:
        return "HOLD"


def get_multiple_news(query, count=5):
    """
    Fetch multiple news articles for the given query
    """
    url = (
        f"https://newsapi.org/v2/everything?"
        f"q={query}&"
        f"apiKey={NEWS_API_KEY}&"
        f"sortBy=publishedAt&"
        f"language=en&"
        f"pageSize={count}"
    )

    try:
        response = requests.get(url, timeout=CONFIG['request_timeout'])  # Add timeout
        response.raise_for_status()  # Raise an error for bad status codes
        data = response.json()

        if data.get("status") == "ok" and data.get("totalResults", 0) > 0:
            articles = []
            for article in data["articles"][:count]:
                # Validate and clean each article
                if article.get("title") and (article.get("content") or article.get("description")):
                    articles.append({
                        "title": article["title"],
                        "content": article.get("content") or article.get("description", ""),
                        "url": article.get("url", ""),
                        "source": article.get("source", {}).get("name", "Unknown"),
                        "publishedAt": article.get("publishedAt", "")
                    })
            return articles
        else:
            print(f"NewsAPI returned no results for query: {query}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"Error fetching news for query {query}: {str(e)}")
        return []
    except Exception as e:
        print(f"Unexpected error fetching news for query {query}: {str(e)}")
        return []


def generate_personalized_recommendation(article_analysis, holdings, market_data):
    """Generate a personalized recommendation based on holdings and market analysis"""
    try:
        # Calculate current position value and profit/loss if holdings exist
        position_summary = ""
        if holdings['numberOfShares'] > 0 and holdings['averageCost'] > 0:
            current_price = float(market_data['last_close'])
            total_investment = holdings['numberOfShares'] * holdings['averageCost']
            current_value = holdings['numberOfShares'] * current_price
            profit_loss = current_value - total_investment
            profit_loss_percent = (profit_loss / total_investment) * 100

            position_summary = f"""Current Position Summary:
- Total Shares: {holdings['numberOfShares']}
- Average Cost: ${holdings['averageCost']:.2f}
- Current Value: ${current_value:.2f}
- Profit/Loss: ${profit_loss:.2f} ({profit_loss_percent:.1f}%)
"""

        # Adjust recommendation based on investment goal and risk tolerance
        risk_factor = {
            'low': 'conservative',
            'medium': 'balanced',
            'high': 'aggressive'
        }[holdings['riskTolerance']]

        time_horizon = {
            'short_term': 'short-term trading opportunities',
            'medium_term': 'medium-term growth potential',
            'long_term': 'long-term value and stability'
        }[holdings['investmentGoal']]

        # Combine all analysis factors
        recommendation = f"""Based on your {risk_factor} risk profile and focus on {time_horizon}, here's your personalized recommendation:

{position_summary if position_summary else ""}
Market Analysis:
{article_analysis}

Personalized Action Items:
"""
        # Add specific action items based on holdings and analysis
        if holdings['numberOfShares'] > 0:
            if article_analysis.upper().find('SELL') != -1:
                recommendation += """
1. Consider taking profits or reducing position size to manage risk
2. Set stop-loss orders to protect gains
3. Review your position size relative to your portfolio"""
            elif article_analysis.upper().find('BUY') != -1:
                recommendation += """
1. Consider increasing your position if it aligns with your portfolio allocation
2. Average up your position on price dips
3. Review your cost basis for tax planning"""
            else:  # HOLD
                recommendation += """
1. Monitor key support/resistance levels
2. Consider setting price alerts for significant movements
3. Review your position size periodically"""
        else:
            if article_analysis.upper().find('BUY') != -1:
                recommendation += """
1. Consider starting a small position aligned with your risk tolerance
2. Use dollar-cost averaging to build position over time
3. Set entry price alerts for optimal buying opportunities"""
            else:
                recommendation += """
1. Continue monitoring for better entry points
2. Set price alerts for your target entry levels
3. Research similar companies in the sector"""

        return recommendation

    except Exception as e:
        print(f"Error generating personalized recommendation: {str(e)}")
        return article_analysis  # Fallback to original analysis if error occurs


# ============================================================
# 3. FLASK ROUTES
# ============================================================

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html')


@app.route('/analyze', methods=['POST'])
def analyze():
    """Analyze a stock ticker and return recommendation"""
    try:
        ticker = request.form.get('ticker', '').upper()
        print(f"\n[INFO] Starting analysis for ticker: {ticker}")
        
        # Get holdings information with proper type conversion and validation
        try:
            num_shares = float(request.form.get('numberOfShares', 0) or 0)
            avg_cost = float(request.form.get('averageCost', 0) or 0)
        except (ValueError, TypeError):
            num_shares = 0
            avg_cost = 0

        holdings = {
            'numberOfShares': num_shares,
            'averageCost': avg_cost,
            'investmentGoal': request.form.get('investmentGoal', 'medium_term'),
            'riskTolerance': request.form.get('riskTolerance', 'medium')
        }

        if not ticker:
            return jsonify({
                'status': 'error',
                'message': 'No ticker symbol provided'
            }), 400

        # Get chart data first
        print("[INFO] Fetching chart data...")
        chart_data = get_historical_chart_data(ticker)
        if chart_data is None:
            print("[WARN] No chart data available, using empty datasets")
            chart_data = {
                'dates': [],
                'prices': [],
                'volumes': []
            }
        else:
            print(f"[INFO] Chart data fetched successfully with {len(chart_data['dates'])} points")
            # Verify data is properly formatted for frontend
            print("[DEBUG] Chart data sample:")
            if chart_data['dates']:
                print(f"First date: {chart_data['dates'][0]}")
                print(f"First price: {chart_data['prices'][0]}")
                print(f"First volume: {chart_data['volumes'][0]}")

        # Fetch news
        article = fetch_latest_news(ticker)
        if not article:
            return jsonify({
                'status': 'error',
                'message': f'No recent news found for {ticker}'
            })

        # Get market data with error handling
        market_data_text, last_close, prev_close, market_cap, weekly_change = get_market_data(ticker)
        
        # Get recommendation
        if index_loaded:
            try:
                recommendation_text, analysis_prompt, similar_articles = analyze_article_with_agent(article)
                
                # Format similar articles for frontend
                formatted_similar_articles = []
                for art in similar_articles:
                    # Convert NumPy types to native Python types
                    formatted_article = {
                        'title': str(art['title']),
                        'content': str(art['content'][:200] + '...' if len(art['content']) > 200 else art['content']),
                        'date': str(art['date']),
                        'source': str(art['source']),
                        'ticker': str(art.get('ticker', ticker)),
                        'similarity_score': float(art['similarity_score']),
                        'reaction': {
                            'price_change': float(art['reaction']['price_change']),
                            'volume_spike': float(art['reaction']['volume_spike'])
                        }
                    }
                    formatted_similar_articles.append(formatted_article)
            except Exception as e:
                print(f"Error in article analysis: {str(e)}")
                recommendation_text = "Unable to analyze article at this time."
                formatted_similar_articles = []
            
            # Generate personalized recommendation
            try:
                personalized_recommendation = generate_personalized_recommendation(
                    recommendation_text,
                    holdings,
                    {'last_close': last_close, 'prev_close': prev_close, 'weekly_change': weekly_change}
                )
            except Exception as e:
                print(f"Error generating personalized recommendation: {str(e)}")
                personalized_recommendation = recommendation_text
            
            decision = parse_recommendation(recommendation_text)
        else:
            personalized_recommendation = "Cannot generate recommendation: historical data not loaded."
            recommendation_text = personalized_recommendation
            analysis_prompt = "N/A"
            decision = "N/A"
            formatted_similar_articles = []

        # Get more news articles
        try:
            recent_news = get_multiple_news(ticker, 5)
        except Exception as e:
            print(f"Error fetching recent news: {str(e)}")
            recent_news = []

        # Create the response with verified chart data
        response_data = {
            'status': 'success',
            'ticker': str(ticker),
            'article': article,
            'recommendation': {
                'text': str(personalized_recommendation),
                'decision': str(decision)
            },
            'market_data': {
                'last_close': str(last_close) if last_close != "N/A" else "N/A",
                'prev_close': str(prev_close) if prev_close != "N/A" else "N/A",
                'market_cap': str(market_cap) if market_cap != "N/A" else "N/A",
                'weekly_change': str(weekly_change) if weekly_change != "N/A" else "N/A"
            },
            'chart_data': chart_data,  # Verified chart data
            'recent_news': recent_news,
            'similar_historical': formatted_similar_articles,
            'holdings_analysis': {
                'shares': float(num_shares),
                'avg_cost': float(avg_cost),
                'current_value': float(last_close) * float(num_shares) if last_close != "N/A" else 0,
                'investment_goal': str(holdings['investmentGoal']),
                'risk_tolerance': str(holdings['riskTolerance'])
            }
        }

        # Verify the response before sending
        print("\n[DEBUG] Verifying response data:")
        print(f"Chart data present: {'chart_data' in response_data}")
        if 'chart_data' in response_data:
            print(f"Number of data points: {len(response_data['chart_data']['dates'])}")

        return jsonify(response_data)
    except Exception as e:
        print(f"[ERROR] Error in analyze endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': f'Error analyzing {ticker}: {str(e)}'
        }), 500


@app.route('/stocks')
def stock_list():
    """Return a list of popular stocks"""
    popular_stocks = [
        {"symbol": "AAPL", "name": "Apple Inc."},
        {"symbol": "MSFT", "name": "Microsoft Corporation"},
        {"symbol": "GOOGL", "name": "Alphabet Inc."},
        {"symbol": "AMZN", "name": "Amazon.com, Inc."},
        {"symbol": "META", "name": "Meta Platforms, Inc."},
        {"symbol": "TSLA", "name": "Tesla, Inc."},
        {"symbol": "NVDA", "name": "NVIDIA Corporation"},
        {"symbol": "JPM", "name": "JPMorgan Chase & Co."},
        {"symbol": "V", "name": "Visa Inc."},
        {"symbol": "WMT", "name": "Walmart Inc."}
    ]
    return jsonify(popular_stocks)


@app.route('/api/market-news')
@cache.cached(timeout=CONFIG['cache_timeout'])  # Cache for 5 minutes
def get_market_news():
    """Fetch latest market news"""
    try:
        # First try to get news for a general market query
        all_news = []
        
        try:
            # Try to get general market news first
            market_news = get_multiple_news("stock market", count=CONFIG['batch_size'])
            if market_news:
                all_news.extend(market_news)
        except Exception as e:
            print(f"Error fetching general market news: {str(e)}")
        
        # If we don't have enough news, fetch for specific sectors
        if len(all_news) < CONFIG['batch_size']:
            for sector in SECTORS.keys():
                try:
                    sector_news = get_multiple_news(sector, count=2)
                    if sector_news:
                        all_news.extend(sector_news)
                except Exception as e:
                    print(f"Error fetching news for sector {sector}: {str(e)}")
                    continue
        
        # Deduplicate news by URL
        seen_urls = set()
        unique_news = []
        for article in all_news:
            if article.get('url') not in seen_urls:
                seen_urls.add(article.get('url'))
                # Ensure all required fields are present
                processed_article = {
                    'title': article.get('title', 'No Title'),
                    'url': article.get('url', '#'),
                    'source': article.get('source', 'Unknown Source'),
                    'publishedAt': article.get('publishedAt', datetime.now().isoformat()),
                    'summary': article.get('content') or article.get('description', 'No content available')
                }
                unique_news.append(processed_article)
        
        # Sort by published date and take the 10 most recent
        unique_news.sort(key=lambda x: x['publishedAt'], reverse=True)
        return jsonify(unique_news[:CONFIG['batch_size']])
        
    except Exception as e:
        print(f"Critical error in get_market_news: {str(e)}")
        # Return a more informative error response
        return jsonify({
            'error': 'Failed to fetch market news',
            'details': str(e)
        }), 500


@app.route('/sectors')
def sectors():
    """Sector analysis page"""
    return render_template('sectors.html', sectors=SECTORS)


@app.route('/api/sector-performance')
@cache.cached(timeout=CONFIG['cache_timeout'])
def get_sector_performance():
    """Get performance data for all sectors"""
    try:
        sector_data = {}
        for sector_name, tickers in SECTORS.items():
            sector_performance = {
                'performance': 0,
                'volume': 0,
                'count': 0
            }
            
            for ticker in tickers:
                try:
                    _, last_close, prev_close, _ = get_yesterdays_market_data(ticker)
                    if last_close != "N/A" and prev_close != "N/A":
                        perf = ((float(last_close) - float(prev_close)) / float(prev_close)) * 100
                        sector_performance['performance'] += perf
                        sector_performance['count'] += 1
                except Exception as e:
                    print(f"Error getting data for {ticker}: {str(e)}")
                    continue
            
            # Calculate average performance
            if sector_performance['count'] > 0:
                sector_performance['performance'] /= sector_performance['count']
            
            sector_data[sector_name] = {
                'performance': round(sector_performance['performance'], 2),
                'stocks': tickers
            }
        
        return jsonify(sector_data)
    except Exception as e:
        return jsonify({
            'error': 'Failed to fetch sector performance',
            'details': str(e)
        }), 500


@app.route('/api/sector-stocks/<sector>')
@cache.cached(timeout=CONFIG['cache_timeout'])
def get_sector_stocks(sector):
    """Get detailed data for stocks in a sector"""
    if sector not in SECTORS:
        return jsonify({'error': 'Invalid sector'}), 404
        
    try:
        stocks_data = []
        for ticker in SECTORS[sector]:
            try:
                market_data_text, last_close, prev_close, market_cap = get_yesterdays_market_data(ticker)
                if last_close != "N/A" and prev_close != "N/A":
                    perf = ((float(last_close) - float(prev_close)) / float(prev_close)) * 100
                    stocks_data.append({
                        'symbol': ticker,
                        'last_close': last_close,
                        'prev_close': prev_close,
                        'performance': round(perf, 2),
                        'market_cap': market_cap
                    })
            except Exception as e:
                print(f"Error getting data for {ticker}: {str(e)}")
                continue
                
        return jsonify(stocks_data)
    except Exception as e:
        return jsonify({
            'error': 'Failed to fetch sector stocks',
            'details': str(e)
        }), 500


def init_app():
    """Initialize the application and its dependencies"""
    # Load environment variables (optional since we have defaults)
    load_dotenv()
    
    # Initialize FAISS
    print("\n[INFO] Starting application initialization...")
    print(f"[INFO] Workspace root: {WORKSPACE_ROOT}")
    print("[INFO] Checking data files:")
    for key, path in DATA_PATHS.items():
        print(f"- {key}: {'Found' if os.path.exists(path) else 'Not found'} at {path}")
    
    if not initialize_faiss():
        print("[WARN] FAISS initialization failed. Some features may be limited.")
    else:
        print("[INFO] FAISS initialization successful!")
        # Test search functionality
        try:
            test_article = {
                'title': 'Test Article',
                'content': 'This is a test article to verify FAISS search functionality.'
            }
            similar = find_similar_articles(test_article, top_k=1)
            print(f"[INFO] Test search successful, found {len(similar)} articles")
        except Exception as e:
            print(f"[ERROR] Test search failed: {str(e)}")
    
    return app

if __name__ == '__main__':
    try:
        app = init_app()
        port = int(os.getenv('PORT', 5001))
        debug = os.getenv('FLASK_ENV', 'development') == 'development'
        
        print(f"\n[INFO] Starting server on port {port} (debug={debug})")
        app.run(
            host='0.0.0.0',
            port=port,
            debug=debug,
            use_reloader=debug
        )
    except Exception as e:
        print(f"[ERROR] Failed to start application: {str(e)}")
        raise